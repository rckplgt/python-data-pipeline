# ETL Project Boilerplate

A simple, modular ETL project using Python.