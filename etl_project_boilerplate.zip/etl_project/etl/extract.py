import pandas as pd
from config.settings import DATA_SOURCE

def extract_data():
    print(f"Extracting data from {DATA_SOURCE}")
    return pd.read_csv(DATA_SOURCE)